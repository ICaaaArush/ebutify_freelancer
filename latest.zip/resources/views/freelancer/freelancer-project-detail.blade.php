@extends('layouts.freelancer-amazon-layout')
@section('content')
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    
    <!-- Main content -->
    <section class="freelancer-message-content">
        <div class="container-fluid">
            <div class="row">
              <div class=" col-12">
                  <div class="message-header pl-4 pt-4">
                    <h3>Direct Chat With Stuff</h3>
                  </div>
                  <div class="freelancer-message-main bg-white m-4">
                    <div class="row">
                        <div class="col-12">
                            <div class="row message-head-area p-3">
                              <div class="col-8">
                                <h3>Direct Chat</h3>
                              </div>
                              <div class="col-4 text-right">
                                  <span class="dc-menu-1" style="background: #FFC107; color: #fff; padding: 0px 7px; border-radius: 5px; margin: 8px 0px;">3</span>
                                  <span class="dc-menu-2 px-1" style="padding: 0px 7px; margin: 8px 0px;"><i class="fas fa-minus"></i></span>
                                  <span aria-hidden="true" style="color: #FF8282; font-size: 26px; padding: 0px 2px; margin-top: -20px;">&times;</span>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div class="message-body-area">
                          <div class="row">
                              <div class="col-12">
                                  <div class="row  pl-2">
                                    <div class="col-md-5 col-sm-12 staff-chat">
                                      <div data-content="#profile1" class="row message-chat-profile active shadow px-3 py-1">
                                        <div class="col-12">
                                          <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                        </div>
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3 p-relative fpd-profile">
                                              <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              <span class="u-indicator online"></span>
                                            </div>
                                            <div class="col-9 pl-2">
                                              <h4  class="mb-0">Biplob Shesk</h4>
                                              <p class="mb-0">How are you mate?</p>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12">
                                          <span class="right-datetime">seen</span>
                                        </div>
                                      </div>
                                      <div data-content="#profile2" class="row message-chat-profile px-3 py-1">
                                        <div class="col-12">
                                          <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                        </div>
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3 fpd-profile">
                                              <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              <span class="u-indicator ideal"></span>
                                            </div>
                                            <div class="col-9 pl-2">
                                              <h4  class="mb-0">Biplob Shesk</h4>
                                              <p class="mb-0">How are you mate?</p>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12">
                                          <span class="right-datetime">seen</span>
                                        </div>
                                      </div>
                                      <div data-content="#profile3" class="row message-chat-profile px-3 py-1">
                                        <div class="col-12">
                                          <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                        </div>
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3 fpd-profile">
                                              <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              <span class="u-indicator online"></span>
                                            </div>
                                            <div class="col-9 pl-2">
                                              <h4  class="mb-0">Biplob Shesk</h4>
                                              <p class="mb-0">How are you mate?</p>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12">
                                          <span class="right-datetime">seen</span>
                                        </div>
                                      </div>
                                      <div data-content="#profile4" class="row message-chat-profile px-3 py-1">
                                        <div class="col-12">
                                          <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                        </div>
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3 fpd-profile">
                                              <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              <span class="u-indicator ideal"></span>
                                            </div>
                                            <div class="col-9 pl-2">
                                              <h4  class="mb-0">Biplob Shesk</h4>
                                              <p class="mb-0">How are you mate?</p>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12">
                                          <span class="right-datetime">seen</span>
                                        </div>
                                      </div>
                                      <div data-content="#profile5" class="row message-chat-profile px-3 py-1">
                                        <div class="col-12">
                                          <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                        </div>
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3 fpd-profile">
                                              <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              <span class="u-indicator ideal"></span>
                                            </div>
                                            <div class="col-9 pl-2">
                                              <h4  class="mb-0">Biplob Shesk</h4>
                                              <p class="mb-0">How are you mate?</p>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12">
                                          <span class="right-datetime">seen</span>
                                        </div>
                                      </div>
                                      <div data-content="#profile6" class="row message-chat-profile px-3 py-1">
                                        <div class="col-12">
                                          <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                        </div>
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3 fpd-profile">
                                              <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              <span class="u-indicator ideal"></span>
                                            </div>
                                            <div class="col-9 pl-2">
                                              <h4  class="mb-0">Biplob Shesk</h4>
                                              <p class="mb-0">How are you mate?</p>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12">
                                          <span class="right-datetime">seen</span>
                                        </div>
                                      </div>
                                    </div>
                                    <div class="col-md-7 col-sm-12 staff-chat">
                                      <div id="profile1" class="message_box">
                                          <div class="message_logs">
                                              <div class="row message friend">
                                                 <div class="col-12">
                                                    <div class="row">
                                                      <div class="col-2 user_photo">
                                                        <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                      </div>
                                                      <div class=" col-7 message_chat">
                                                        <span>27/03/2021 on 10:00 am</span>
                                                        <p>1 Mate did you check my work? The task was fulfill and reviewed 
                                                          by @Rana</p>
                                                      </div>
                                                    </div>
                                                 </div>
                                              </div>
                                              <div class="row message self">
                                                <div class="col-12">
                                                   <div class="row">
                                                     <div class="col-3"></div>
                                                     <div class="col-7 message_chat">
                                                       <div class="row self_message_chat">
                                                         <div class="col-12">
                                                          <span>27/03/2021 on 10:00 am</span>
                                                         </div>
                                                         <div class="col-12">
                                                          <p>Yes, I did. Good job. Carry on mate!</p>
                                                         </div>
                                                       </div>
                                                     </div>
                                                     <div class="col-2 user_photo">
                                                      <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                    </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="row message friend">
                                              <div class="col-12">
                                                 <div class="row">
                                                   <div class="col-2 user_photo">
                                                     <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                   </div>
                                                   <div class=" col-7 message_chat">
                                                     <span>27/03/2021 on 10:00 am</span>
                                                     <p>Thank you so much mate!</p>
                                                   </div>
                                                 </div>
                                              </div>
                                           </div>
                                           <div class="row message self">
                                            <div class="col-12">
                                               <div class="row">
                                                 <div class="col-3"></div>
                                                 <div class="col-7 message_chat">
                                                   <div class="row self_message_chat">
                                                     <div class="col-12">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                     </div>
                                                     <div class="col-12">
                                                      <p>How are you mate?</p>
                                                     </div>
                                                   </div>
                                                 </div>
                                                 <div class="col-2 user_photo">
                                                  <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                </div>
                                               </div>
                                            </div>
                                         </div>
                                          </div>
                                          <div class="chat_form">
                                              <input type="text" class="msg-input" placeholder="Write something" />
                                              <button>Send</button>
                                          </div>
                                      </div>

                                      <div id="profile2" class="message_box" style="display: none;">
                                        <div class="message_logs">
                                            <div class="row message friend">
                                               <div class="col-12">
                                                  <div class="row">
                                                    <div class="col-2 user_photo">
                                                      <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                    </div>
                                                    <div class=" col-7 message_chat">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                      <p>2 Mate did you check my work? The task was fulfill and reviewed 
                                                        by @Rana</p>
                                                    </div>
                                                  </div>
                                               </div>
                                            </div>
                                            <div class="row message self">
                                              <div class="col-12">
                                                 <div class="row">
                                                   <div class="col-3"></div>
                                                   <div class="col-7 message_chat">
                                                     <div class="row self_message_chat">
                                                       <div class="col-12">
                                                        <span>27/03/2021 on 10:00 am</span>
                                                       </div>
                                                       <div class="col-12">
                                                        <p>Yes, I did. Good job. Carry on mate!</p>
                                                       </div>
                                                     </div>
                                                   </div>
                                                   <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                 </div>
                                              </div>
                                           </div>
                                           <div class="row message friend">
                                            <div class="col-12">
                                               <div class="row">
                                                 <div class="col-2 user_photo">
                                                   <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                 </div>
                                                 <div class=" col-7 message_chat">
                                                   <span>27/03/2021 on 10:00 am</span>
                                                   <p>Thank you so much mate!</p>
                                                 </div>
                                               </div>
                                            </div>
                                         </div>
                                         <div class="row message self">
                                          <div class="col-12">
                                             <div class="row">
                                               <div class="col-3"></div>
                                               <div class="col-7 message_chat">
                                                 <div class="row self_message_chat">
                                                   <div class="col-12">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                   </div>
                                                   <div class="col-12">
                                                    <p>How are you mate?</p>
                                                   </div>
                                                 </div>
                                               </div>
                                               <div class="col-2 user_photo">
                                                <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                             </div>
                                          </div>
                                       </div>
                                        </div>
                                        <div class="chat_form">
                                            <input type="text" class="msg-input" placeholder="Write something" />
                                            <button>Send</button>
                                        </div>
                                      </div>

                                      <div id="profile3" class="message_box" style="display: none;">
                                        <div class="message_logs">
                                            <div class="row message friend">
                                               <div class="col-12">
                                                  <div class="row">
                                                    <div class="col-2 user_photo">
                                                      <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                    </div>
                                                    <div class=" col-7 message_chat">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                      <p>3 Mate did you check my work? The task was fulfill and reviewed 
                                                        by @Rana</p>
                                                    </div>
                                                  </div>
                                               </div>
                                            </div>
                                            <div class="row message self">
                                              <div class="col-12">
                                                 <div class="row">
                                                   <div class="col-3"></div>
                                                   <div class="col-7 message_chat">
                                                     <div class="row self_message_chat">
                                                       <div class="col-12">
                                                        <span>27/03/2021 on 10:00 am</span>
                                                       </div>
                                                       <div class="col-12">
                                                        <p>Yes, I did. Good job. Carry on mate!</p>
                                                       </div>
                                                     </div>
                                                   </div>
                                                   <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                 </div>
                                              </div>
                                           </div>
                                           <div class="row message friend">
                                            <div class="col-12">
                                               <div class="row">
                                                 <div class="col-2 user_photo">
                                                   <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                 </div>
                                                 <div class=" col-7 message_chat">
                                                   <span>27/03/2021 on 10:00 am</span>
                                                   <p>Thank you so much mate!</p>
                                                 </div>
                                               </div>
                                            </div>
                                         </div>
                                         <div class="row message self">
                                          <div class="col-12">
                                             <div class="row">
                                               <div class="col-3"></div>
                                               <div class="col-7 message_chat">
                                                 <div class="row self_message_chat">
                                                   <div class="col-12">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                   </div>
                                                   <div class="col-12">
                                                    <p>How are you mate?</p>
                                                   </div>
                                                 </div>
                                               </div>
                                               <div class="col-2 user_photo">
                                                <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                             </div>
                                          </div>
                                       </div>
                                        </div>
                                        <div class="chat_form">
                                            <input type="text" class="msg-input" placeholder="Write something" />
                                            <button>Send</button>
                                        </div>
                                      </div>

                                      <div id="profile4" class="message_box" style="display: none;">
                                        <div class="message_logs">
                                            <div class="row message friend">
                                               <div class="col-12">
                                                  <div class="row">
                                                    <div class="col-2 user_photo">
                                                      <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                    </div>
                                                    <div class=" col-7 message_chat">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                      <p>4 Mate did you check my work? The task was fulfill and reviewed 
                                                        by @Rana</p>
                                                    </div>
                                                  </div>
                                               </div>
                                            </div>
                                            <div class="row message self">
                                              <div class="col-12">
                                                 <div class="row">
                                                   <div class="col-3"></div>
                                                   <div class="col-7 message_chat">
                                                     <div class="row self_message_chat">
                                                       <div class="col-12">
                                                        <span>27/03/2021 on 10:00 am</span>
                                                       </div>
                                                       <div class="col-12">
                                                        <p>Yes, I did. Good job. Carry on mate!</p>
                                                       </div>
                                                     </div>
                                                   </div>
                                                   <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                 </div>
                                              </div>
                                           </div>
                                           <div class="row message friend">
                                            <div class="col-12">
                                               <div class="row">
                                                 <div class="col-2 user_photo">
                                                   <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                 </div>
                                                 <div class=" col-7 message_chat">
                                                   <span>27/03/2021 on 10:00 am</span>
                                                   <p>Thank you so much mate!</p>
                                                 </div>
                                               </div>
                                            </div>
                                         </div>
                                         <div class="row message self">
                                          <div class="col-12">
                                             <div class="row">
                                               <div class="col-3"></div>
                                               <div class="col-7 message_chat">
                                                 <div class="row self_message_chat">
                                                   <div class="col-12">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                   </div>
                                                   <div class="col-12">
                                                    <p>How are you mate?</p>
                                                   </div>
                                                 </div>
                                               </div>
                                               <div class="col-2 user_photo">
                                                <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                             </div>
                                          </div>
                                       </div>
                                        </div>
                                        <div class="chat_form">
                                            <input type="text" class="msg-input" placeholder="Write something" />
                                            <button>Send</button>
                                        </div>
                                      </div>

                                      <div id="profile5" class="message_box" style="display: none;">
                                        <div class="message_logs">
                                            <div class="row message friend">
                                               <div class="col-12">
                                                  <div class="row">
                                                    <div class="col-2 user_photo">
                                                      <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                    </div>
                                                    <div class=" col-7 message_chat">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                      <p>5 Mate did you check my work? The task was fulfill and reviewed 
                                                        by @Rana</p>
                                                    </div>
                                                  </div>
                                               </div>
                                            </div>
                                            <div class="row message self">
                                              <div class="col-12">
                                                 <div class="row">
                                                   <div class="col-3"></div>
                                                   <div class="col-7 message_chat">
                                                     <div class="row self_message_chat">
                                                       <div class="col-12">
                                                        <span>27/03/2021 on 10:00 am</span>
                                                       </div>
                                                       <div class="col-12">
                                                        <p>Yes, I did. Good job. Carry on mate!</p>
                                                       </div>
                                                     </div>
                                                   </div>
                                                   <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                 </div>
                                              </div>
                                           </div>
                                           <div class="row message friend">
                                            <div class="col-12">
                                               <div class="row">
                                                 <div class="col-2 user_photo">
                                                   <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                 </div>
                                                 <div class=" col-7 message_chat">
                                                   <span>27/03/2021 on 10:00 am</span>
                                                   <p>Thank you so much mate!</p>
                                                 </div>
                                               </div>
                                            </div>
                                         </div>
                                         <div class="row message self">
                                          <div class="col-12">
                                             <div class="row">
                                               <div class="col-3"></div>
                                               <div class="col-7 message_chat">
                                                 <div class="row self_message_chat">
                                                   <div class="col-12">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                   </div>
                                                   <div class="col-12">
                                                    <p>How are you mate?</p>
                                                   </div>
                                                 </div>
                                               </div>
                                               <div class="col-2 user_photo">
                                                <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                             </div>
                                          </div>
                                       </div>
                                        </div>
                                        <div class="chat_form">
                                            <input type="text" class="msg-input" placeholder="Write something" />
                                            <button>Send</button>
                                        </div>
                                      </div>

                                      <div id="profile6" class="message_box" style="display: none;">
                                        <div class="message_logs">
                                            <div class="row message friend">
                                               <div class="col-12">
                                                  <div class="row">
                                                    <div class="col-2 user_photo">
                                                      <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                    </div>
                                                    <div class=" col-7 message_chat">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                      <p>6 Mate did you check my work? The task was fulfill and reviewed 
                                                        by @Rana</p>
                                                    </div>
                                                  </div>
                                               </div>
                                            </div>
                                            <div class="row message self">
                                              <div class="col-12">
                                                 <div class="row">
                                                   <div class="col-3"></div>
                                                   <div class="col-7 message_chat">
                                                     <div class="row self_message_chat">
                                                       <div class="col-12">
                                                        <span>27/03/2021 on 10:00 am</span>
                                                       </div>
                                                       <div class="col-12">
                                                        <p>Yes, I did. Good job. Carry on mate!</p>
                                                       </div>
                                                     </div>
                                                   </div>
                                                   <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                 </div>
                                              </div>
                                           </div>
                                           <div class="row message friend">
                                            <div class="col-12">
                                               <div class="row">
                                                 <div class="col-2 user_photo">
                                                   <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                 </div>
                                                 <div class=" col-7 message_chat">
                                                   <span>27/03/2021 on 10:00 am</span>
                                                   <p>Thank you so much mate!</p>
                                                 </div>
                                               </div>
                                            </div>
                                         </div>
                                         <div class="row message self">
                                          <div class="col-12">
                                             <div class="row">
                                               <div class="col-3"></div>
                                               <div class="col-7 message_chat">
                                                 <div class="row self_message_chat">
                                                   <div class="col-12">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                   </div>
                                                   <div class="col-12">
                                                    <p>How are you mate?</p>
                                                   </div>
                                                 </div>
                                               </div>
                                               <div class="col-2 user_photo">
                                                <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                             </div>
                                          </div>
                                       </div>
                                        </div>
                                        <div class="chat_form">
                                            <input type="text" class="msg-input" placeholder="Write something" />
                                            <button>Send</button>
                                        </div>
                                      </div>

                                    </div>
                                  </div>
                              </div>
                          </div>
                    </div>
                  </div>    
              </div>
              <div class=" col-12">
                <div class="message-header pl-4 pt-4">
                  <h3>Direct Chat With Client</h3>
                </div>
                <div class="freelancer-message-main bg-white m-4">
                  <div class="row">
                      <div class="col-12">
                          <div class="row message-head-area p-3">
                            <div class="col-8">
                              <h3>Direct Chat</h3>
                            </div>
                            <div class="col-4 text-right">
                                <span class="dc-menu-1" style="background: #FFC107; color: #fff; padding: 0px 7px; border-radius: 5px; margin: 8px 0px;">3</span>
                                <span class="dc-menu-2 px-1" style="padding: 0px 7px; margin: 8px 0px;"><i class="fas fa-minus"></i></span>
                                <span aria-hidden="true" style="color: #FF8282; font-size: 26px; padding: 0px 2px; margin-top: -20px;">&times;</span>
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="message-body-area">
                    <div class="row">
                        <div class="col-12">
                            <div class="row  pl-2">
                              <div class="col-md-5 col-sm-12 client-chat">
                                    <div data-content="#profile1" class="row message-chat-profile active shadow px-3 py-1">
                                      <div class="col-12">
                                        <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                      </div>
                                      <div class="col-12">
                                        <div class="row group-chat-img">
                                          <div class="col-3 fpd-profile">
                                            <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            <span class="u-indicator online"></span>
                                          </div>
                                          <div class="col-9 pl-2">
                                            <h4  class="mb-0">Biplob Shesk</h4>
                                            <p class="mb-0">How are you mate?</p>
                                          </div>
                                        </div>
                                          <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid group-chat-img-1" alt="">
                                          <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid group-chat-img-2" alt="">
                                          <img src="assets/img/user1-128x128.jpg" class="img-circle mx-auto d-block img-fluid group-chat-img-3" alt="">
                                      </div>
                                      <div class="col-12">
                                        <span class="right-datetime">seen</span>
                                      </div>
                                    </div>
                                    <div data-content="#profile2" class="row message-chat-profile px-3 py-1">
                                      <div class="col-12">
                                        <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                      </div>
                                      <div class="col-12">
                                        <div class="row group-chat-img">
                                          <div class="col-3 fpd-profile">
                                            <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            <span class="u-indicator ideal"></span>
                                          </div>
                                          <div class="col-9 pl-2">
                                            <h4  class="mb-0">Biplob Shesk</h4>
                                            <p class="mb-0">How are you mate?</p>
                                          </div>
                                        </div>
                                          <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid group-chat-img-1" alt="">
                                          <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid group-chat-img-2" alt="">
                                          <img src="assets/img/user1-128x128.jpg" class="img-circle mx-auto d-block img-fluid group-chat-img-3" alt="">
                                      </div>
                                      <div class="col-12">
                                        <span class="right-datetime">seen</span>
                                      </div>
                                    </div>
                                    <div data-content="#profile3" class="row message-chat-profile px-3 py-1">
                                      <div class="col-12">
                                        <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                      </div>
                                      <div class="col-12">
                                        <div class="row">
                                          <div class="col-3 fpd-profile">
                                            <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            <span class="u-indicator online"></span>
                                          </div>
                                          <div class="col-9 pl-2">
                                            <h4  class="mb-0">Biplob Shesk</h4>
                                            <p class="mb-0">How are you mate?</p>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="col-12">
                                        <span class="right-datetime">seen</span>
                                      </div>
                                    </div>
                                    <div data-content="#profile4" class="row message-chat-profile px-3 py-1">
                                      <div class="col-12">
                                        <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                      </div>
                                      <div class="col-12">
                                        <div class="row">
                                          <div class="col-3 fpd-profile">
                                            <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            <span class="u-indicator ideal"></span>
                                          </div>
                                          <div class="col-9 pl-2">
                                            <h4  class="mb-0">Biplob Shesk</h4>
                                            <p class="mb-0">How are you mate?</p>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="col-12">
                                        <span class="right-datetime">seen</span>
                                      </div>
                                    </div>
                                    <div data-content="#profile6" class="row message-chat-profile px-3 py-1">
                                      <div class="col-12">
                                        <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                      </div>
                                      <div class="col-12">
                                        <div class="row">
                                          <div class="col-3 fpd-profile">
                                            <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            <span class="u-indicator ideal"></span>
                                          </div>
                                          <div class="col-9 pl-2">
                                            <h4  class="mb-0">Biplob Shesk</h4>
                                            <p class="mb-0">How are you mate?</p>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="col-12">
                                        <span class="right-datetime">seen</span>
                                      </div>
                                    </div>
                                    <div data-content="#profile7" class="row message-chat-profile px-3 py-1">
                                      <div class="col-12">
                                        <span class="right-datetime">21/03/2021 on 6:45 pm</span>
                                      </div>
                                      <div class="col-12">
                                        <div class="row">
                                          <div class="col-3 fpd-profile">
                                            <img src="assets/img/avatar3.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            <span class="u-indicator ideal"></span>
                                          </div>
                                          <div class="col-9 pl-2">
                                            <h4  class="mb-0">Biplob Shesk</h4>
                                            <p class="mb-0">How are you mate?</p>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="col-12">
                                        <span class="right-datetime">seen</span>
                                      </div>
                                    </div>
                              </div>
                              <div class="col-md-7 col-sm-12 client-chat">
                                    <div id="profile1" class="message_box">
                                          <div class="message_logs">
                                              <div class="row message friend">
                                                <div class="col-12">
                                                    <div class="row">
                                                      <div class="col-2 user_photo">
                                                        <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                      </div>
                                                      <div class=" col-7 message_chat">
                                                        <span>27/03/2021 on 10:00 am</span>
                                                        <p>001 Mate did you check my work? The task was fulfill and reviewed 
                                                          by @Rana</p>
                                                      </div>
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="row message self">
                                                <div class="col-12">
                                                  <div class="row">
                                                    <div class="col-3"></div>
                                                    <div class="col-7 message_chat">
                                                      <div class="row self_message_chat">
                                                        <div class="col-12">
                                                          <span>27/03/2021 on 10:00 am</span>
                                                        </div>
                                                        <div class="col-12">
                                                          <p>Yes, I did. Good job. Carry on mate!</p>
                                                        </div>
                                                      </div>
                                                    </div>
                                                    <div class="col-2 user_photo">
                                                      <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                    </div>
                                                  </div>
                                                </div>
                                            </div>
                                            <div class="row message friend">
                                              <div class="col-12">
                                                <div class="row">
                                                  <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                  <div class=" col-7 message_chat">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                    <p>Thank you so much mate!</p>
                                                  </div>
                                                </div>
                                              </div>
                                          </div>
                                          <div class="row message self">
                                            <div class="col-12">
                                              <div class="row">
                                                <div class="col-3"></div>
                                                <div class="col-7 message_chat">
                                                  <div class="row self_message_chat">
                                                    <div class="col-12">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                    </div>
                                                    <div class="col-12">
                                                      <p>How are you mate?</p>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="col-2 user_photo">
                                                  <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                </div>
                                              </div>
                                            </div>
                                        </div>
                                          </div>
                                          <div class="chat_form">
                                              <input type="text" class="msg-input" placeholder="Write something" />
                                              <button>Send</button>
                                          </div>
                                    </div>

                                    <div id="profile2" class="message_box" style="display: none;">
                                      <div class="message_logs">
                                          <div class="row message friend">
                                            <div class="col-12">
                                                <div class="row">
                                                  <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                  <div class=" col-7 message_chat">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                    <p> 002 Mate did you check my work? The task was fulfill and reviewed 
                                                      by @Rana</p>
                                                  </div>
                                                </div>
                                            </div>
                                          </div>
                                          <div class="row message self">
                                            <div class="col-12">
                                              <div class="row">
                                                <div class="col-3"></div>
                                                <div class="col-7 message_chat">
                                                  <div class="row self_message_chat">
                                                    <div class="col-12">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                    </div>
                                                    <div class="col-12">
                                                      <p>Yes, I did. Good job. Carry on mate!</p>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="col-2 user_photo">
                                                  <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                </div>
                                              </div>
                                            </div>
                                        </div>
                                        <div class="row message friend">
                                          <div class="col-12">
                                            <div class="row">
                                              <div class="col-2 user_photo">
                                                <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                              <div class=" col-7 message_chat">
                                                <span>27/03/2021 on 10:00 am</span>
                                                <p>Thank you so much mate!</p>
                                              </div>
                                            </div>
                                          </div>
                                      </div>
                                      <div class="row message self">
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3"></div>
                                            <div class="col-7 message_chat">
                                              <div class="row self_message_chat">
                                                <div class="col-12">
                                                  <span>27/03/2021 on 10:00 am</span>
                                                </div>
                                                <div class="col-12">
                                                  <p>How are you mate?</p>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="col-2 user_photo">
                                              <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            </div>
                                          </div>
                                        </div>
                                    </div>
                                      </div>
                                      <div class="chat_form">
                                          <input type="text" class="msg-input" placeholder="Write something" />
                                          <button>Send</button>
                                      </div>
                                    </div>

                                    <div id="profile3" class="message_box" style="display: none;">
                                      <div class="message_logs">
                                          <div class="row message friend">
                                            <div class="col-12">
                                                <div class="row">
                                                  <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                  <div class=" col-7 message_chat">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                    <p> 003 Mate did you check my work? The task was fulfill and reviewed 
                                                      by @Rana</p>
                                                  </div>
                                                </div>
                                            </div>
                                          </div>
                                          <div class="row message self">
                                            <div class="col-12">
                                              <div class="row">
                                                <div class="col-3"></div>
                                                <div class="col-7 message_chat">
                                                  <div class="row self_message_chat">
                                                    <div class="col-12">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                    </div>
                                                    <div class="col-12">
                                                      <p>Yes, I did. Good job. Carry on mate!</p>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="col-2 user_photo">
                                                  <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                </div>
                                              </div>
                                            </div>
                                        </div>
                                        <div class="row message friend">
                                          <div class="col-12">
                                            <div class="row">
                                              <div class="col-2 user_photo">
                                                <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                              <div class=" col-7 message_chat">
                                                <span>27/03/2021 on 10:00 am</span>
                                                <p>Thank you so much mate!</p>
                                              </div>
                                            </div>
                                          </div>
                                      </div>
                                      <div class="row message self">
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3"></div>
                                            <div class="col-7 message_chat">
                                              <div class="row self_message_chat">
                                                <div class="col-12">
                                                  <span>27/03/2021 on 10:00 am</span>
                                                </div>
                                                <div class="col-12">
                                                  <p>How are you mate?</p>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="col-2 user_photo">
                                              <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            </div>
                                          </div>
                                        </div>
                                    </div>
                                      </div>
                                      <div class="chat_form">
                                          <input type="text" class="msg-input" placeholder="Write something" />
                                          <button>Send</button>
                                      </div>
                                    </div>

                                    <div id="profile4" class="message_box" style="display: none;">
                                      <div class="message_logs">
                                          <div class="row message friend">
                                            <div class="col-12">
                                                <div class="row">
                                                  <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                  <div class=" col-7 message_chat">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                    <p> 004 Mate did you check my work? The task was fulfill and reviewed 
                                                      by @Rana</p>
                                                  </div>
                                                </div>
                                            </div>
                                          </div>
                                          <div class="row message self">
                                            <div class="col-12">
                                              <div class="row">
                                                <div class="col-3"></div>
                                                <div class="col-7 message_chat">
                                                  <div class="row self_message_chat">
                                                    <div class="col-12">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                    </div>
                                                    <div class="col-12">
                                                      <p>Yes, I did. Good job. Carry on mate!</p>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="col-2 user_photo">
                                                  <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                </div>
                                              </div>
                                            </div>
                                        </div>
                                        <div class="row message friend">
                                          <div class="col-12">
                                            <div class="row">
                                              <div class="col-2 user_photo">
                                                <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                              <div class=" col-7 message_chat">
                                                <span>27/03/2021 on 10:00 am</span>
                                                <p>Thank you so much mate!</p>
                                              </div>
                                            </div>
                                          </div>
                                      </div>
                                      <div class="row message self">
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3"></div>
                                            <div class="col-7 message_chat">
                                              <div class="row self_message_chat">
                                                <div class="col-12">
                                                  <span>27/03/2021 on 10:00 am</span>
                                                </div>
                                                <div class="col-12">
                                                  <p>How are you mate?</p>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="col-2 user_photo">
                                              <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            </div>
                                          </div>
                                        </div>
                                    </div>
                                      </div>
                                      <div class="chat_form">
                                          <input type="text" class="msg-input" placeholder="Write something" />
                                          <button>Send</button>
                                      </div>
                                    </div>

                                    <div id="profile5" class="message_box" style="display: none;">
                                      <div class="message_logs">
                                          <div class="row message friend">
                                            <div class="col-12">
                                                <div class="row">
                                                  <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                  <div class=" col-7 message_chat">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                    <p> 005 Mate did you check my work? The task was fulfill and reviewed 
                                                      by @Rana</p>
                                                  </div>
                                                </div>
                                            </div>
                                          </div>
                                          <div class="row message self">
                                            <div class="col-12">
                                              <div class="row">
                                                <div class="col-3"></div>
                                                <div class="col-7 message_chat">
                                                  <div class="row self_message_chat">
                                                    <div class="col-12">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                    </div>
                                                    <div class="col-12">
                                                      <p>Yes, I did. Good job. Carry on mate!</p>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="col-2 user_photo">
                                                  <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                </div>
                                              </div>
                                            </div>
                                        </div>
                                        <div class="row message friend">
                                          <div class="col-12">
                                            <div class="row">
                                              <div class="col-2 user_photo">
                                                <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                              <div class=" col-7 message_chat">
                                                <span>27/03/2021 on 10:00 am</span>
                                                <p>Thank you so much mate!</p>
                                              </div>
                                            </div>
                                          </div>
                                      </div>
                                      <div class="row message self">
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3"></div>
                                            <div class="col-7 message_chat">
                                              <div class="row self_message_chat">
                                                <div class="col-12">
                                                  <span>27/03/2021 on 10:00 am</span>
                                                </div>
                                                <div class="col-12">
                                                  <p>How are you mate?</p>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="col-2 user_photo">
                                              <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            </div>
                                          </div>
                                        </div>
                                    </div>
                                      </div>
                                      <div class="chat_form">
                                          <input type="text" class="msg-input" placeholder="Write something" />
                                          <button>Send</button>
                                      </div>
                                    </div>

                                    <div id="profile6" class="message_box" style="display: none;">
                                      <div class="message_logs">
                                          <div class="row message friend">
                                            <div class="col-12">
                                                <div class="row">
                                                  <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                  <div class=" col-7 message_chat">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                    <p> 006 Mate did you check my work? The task was fulfill and reviewed 
                                                      by @Rana</p>
                                                  </div>
                                                </div>
                                            </div>
                                          </div>
                                          <div class="row message self">
                                            <div class="col-12">
                                              <div class="row">
                                                <div class="col-3"></div>
                                                <div class="col-7 message_chat">
                                                  <div class="row self_message_chat">
                                                    <div class="col-12">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                    </div>
                                                    <div class="col-12">
                                                      <p>Yes, I did. Good job. Carry on mate!</p>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="col-2 user_photo">
                                                  <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                </div>
                                              </div>
                                            </div>
                                        </div>
                                        <div class="row message friend">
                                          <div class="col-12">
                                            <div class="row">
                                              <div class="col-2 user_photo">
                                                <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                              <div class=" col-7 message_chat">
                                                <span>27/03/2021 on 10:00 am</span>
                                                <p>Thank you so much mate!</p>
                                              </div>
                                            </div>
                                          </div>
                                      </div>
                                      <div class="row message self">
                                        <div class="col-12">
                                          <div class="row">
                                            <div class="col-3"></div>
                                            <div class="col-7 message_chat">
                                              <div class="row self_message_chat">
                                                <div class="col-12">
                                                  <span>27/03/2021 on 10:00 am</span>
                                                </div>
                                                <div class="col-12">
                                                  <p>How are you mate?</p>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="col-2 user_photo">
                                              <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                            </div>
                                          </div>
                                        </div>
                                    </div>
                                      </div>
                                      <div class="chat_form">
                                          <input type="text" class="msg-input" placeholder="Write something" />
                                          <button>Send</button>
                                      </div>
                                    </div>

                                    <div id="profile7" class="message_box" style="display: none;">
                                      <div class="message_logs">
                                          <div class="row message friend">
                                            <div class="col-12">
                                                <div class="row">
                                                  <div class="col-2 user_photo">
                                                    <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                  </div>
                                                  <div class=" col-7 message_chat">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                    <p> 007 Mate did you check my work? The task was fulfill and reviewed 
                                                      by @Rana</p>
                                                  </div>
                                                </div>
                                            </div>
                                          </div>
                                          <div class="row message self">
                                            <div class="col-12">
                                              <div class="row">
                                                <div class="col-3"></div>
                                                <div class="col-7 message_chat">
                                                  <div class="row self_message_chat">
                                                    <div class="col-12">
                                                      <span>27/03/2021 on 10:00 am</span>
                                                    </div>
                                                    <div class="col-12">
                                                      <p>Yes, I did. Good job. Carry on mate!</p>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="col-2 user_photo">
                                                  <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        <div class="row message friend">
                                          <div class="col-12">
                                            <div class="row">
                                              <div class="col-2 user_photo">
                                                <img src="assets/img/avatar4.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                              <div class=" col-7 message_chat">
                                                <span>27/03/2021 on 10:00 am</span>
                                                <p>Thank you so much mate!</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="row message self">
                                          <div class="col-12">
                                            <div class="row">
                                              <div class="col-3"></div>
                                              <div class="col-7 message_chat">
                                                <div class="row self_message_chat">
                                                  <div class="col-12">
                                                    <span>27/03/2021 on 10:00 am</span>
                                                  </div>
                                                  <div class="col-12">
                                                    <p>How are you mate?</p>
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="col-2 user_photo">
                                                <img src="assets/img/avatar5.png" class="img-circle mx-auto d-block img-fluid" alt="">
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="chat_form">
                                            <input type="text" class="msg-input" placeholder="Write something" />
                                            <button>Send</button>
                                      </div>
                                    </div>
                              </div> 
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        
        
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
</div>
<!-- ./wrapper -->
@endsection