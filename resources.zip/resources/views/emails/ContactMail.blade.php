<!DOCTYPE html>
<html>
<head>
	<title>Contact Form</title>
</head>
<body>
	<h1>Contact Message</h1>
	<p>Subject : {{$details['subject']}}</p>
	<p>Message : {{$details['message']}}</p>
</body>
</html>